# FlightDelay

[![FlighDelay](http://i.imgur.com/bHFDB3D.png)]


“Cleared for Take Off” challenge


Can an app be developed that predicts the impact of weather on airplane departure times?

YES

Is it needed?
YES YES YES

WHAT


Inform Passengers when flight delays are expected due to Weather factors.
Present in a simple manner the minimum legal requirements vs. actual conditions.
List Passenger’s Rights in case of major delays!

HOW


Creating a “Captain Overview” app to analyze the “Operational Reasons”:
Weather actual and short term forecast at departure + destination
(wind gusts, wind shear, icing (deicing), fog (LVO) in relation to airport capabilities, Weather en-route)
Integrating this data with:
Airport limitations
Company / Aircraft type limitations
BONUS: Reactionary (aircraft arriving with delay from its previous flight will automatically create a delay for the next departure)


CONCLUSION


This app can be further developed to help Passengers better manage their waiting time. Additionally, we can present near-by facilities in terminal (coffee shops, baby changing stations, etc…) and, why not, even encourage airlines to use this app in order communicate better with their customers when the difficult situation will arise.
