<?php
App::uses('AppController', 'Controller');

class HomeController extends AppController {


	public $uses = array('Airport');
	public $components = array('Distance', 'Weather');
	public function index()
	{

    	if (!empty($this->data))
		{
			// procesam
			$data = $this->data;
			$aircraftTypes = Configure::read('aircraftTypes');

			//Romatsa stuff

			$data['Airport']['flightnr'] = strtoupper($data['Airport']['flightnr']);
			$from = strtoupper($this->data['Airport']['from']);
			$romatsa = new RomatsaParser();
			$romatsa->index($from);
			$romatsa = $romatsa->get_airport_data();

			$to = '';
			for($i = 0; $i < count($romatsa['departures']); $i++)
			{
				if($romatsa['departures'][$i]['flight'] == $data['Airport']['flightnr'])
				{
					$to = $romatsa['departures'][$i]['to'];
					$aircraftType = $romatsa['departures'][$i]['type'];
					$estimatedDeparture = $romatsa['departures'][$i]['eobt'];
					$company = $romatsa['departures'][$i]['company'];
					$flightPlanData = $romatsa['departures'][$i];
				}
			}

			$data['Airport']['from'] = $from;

			$fromData = $this->Airport->find('all', array('conditions' => array('icao' => $from)));
			$toData = $this->Airport->find('all', array('conditions' => array('icao' => $to)));

			$distance = $this->Airport->query('SELECT ST_Distance(dep.geog, dest.geog) as distance FROM airports dep, airports dest WHERE dep.icao=\''.$from.'\' AND dest.icao=\''.$to.'\'');

			$distance_in_meters = $distance[0][0]['distance'];
			$distance_in_nm = $this->Distance->get_meters_to_nm($distance_in_meters);
			$estimated_time_route = $this->Distance->get_time_for_distance($distance_in_nm, $aircraftTypes[$aircraftType]['cruiseSpeed']); // speed in kts as demo

			//weather data
			$fromWeather = $this->Weather->getMetar($from);
			$fromWeather = $this->Weather->decode_metar($fromWeather);
			$weathertTextFrom = $this->Weather->estimateTimeliness($fromWeather, 'dep');


			$toWeather = $this->Weather->getMetar($to);
			$toWeather = $this->Weather->decode_metar($toWeather);
			$weathertTextTo = $this->Weather->estimateTimeliness($toWeather, 'arr', $toData[0]['Airport']['ils_cat']);


			$this->data = $data;
			$this->set(compact('fromData', 'toData','distance_in_nm', 'estimated_time_route',
				'fromWeather', 'toWeather','fr24data', 'weathertTextFrom', 'weathertTextTo',
				'estimatedDeparture', 'aircraftType', 'company', 'flightPlanData'));

		}

	}

	public function rights()
	{}
}
