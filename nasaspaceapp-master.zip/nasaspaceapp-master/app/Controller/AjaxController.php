<?php
App::uses('AppController', 'Controller');

class AjaxController extends AppController {


	public $uses = array('Airport');
//	public $components = array('Distance', 'Weather', 'Fr24', 'Google');
	public function getairports()
	{
//		echo $_POST['latitude'].' '.$_POST['longitude'];

		$sql = "SELECT airports.*, ST_Distance(geog, poi)/1000 AS distance_km
				FROM airports,
				  (select ST_MakePoint(".$_POST['longitude'].", ".$_POST['latitude'].")::geography as poi) as poi
				WHERE ST_DWithin(geog, poi, 25000) and icao!='' and iata!=''
				ORDER BY ST_Distance(geog, poi)
				LIMIT 10;";

		$airport_list = $this->Airport->query($sql);

		foreach($airport_list as $ap)
		{
			$airport['name'] = $ap[0]['name'];
			$airport['city'] = $ap[0]['city'];
			$airport['country'] = $ap[0]['country'];
			$airport['icao'] = $ap[0]['icao'];
			$airport['iata'] = $ap[0]['iata'];
			$airport['distance'] = $ap[0]['distance_km'];
			$airports[] = $airport;
		}
		echo json_encode($airports);
		die();
	}

	public function getFlights()
	{
		$from = $_POST['airportIcao'];
		$romatsa = new RomatsaParser();
		$romatsa->index($from);
		$romatsa = $romatsa->get_airport_data();

		$to = '';
		for($i = 0; $i < count($romatsa['departures']); $i++)
		{
			$flightPlanData[] = $romatsa['departures'][$i];
		}

		echo json_encode($flightPlanData);
		die();
	}
}
