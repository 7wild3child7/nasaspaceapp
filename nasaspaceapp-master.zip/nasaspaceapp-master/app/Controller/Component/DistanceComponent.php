<?php
class DistanceComponent extends Component
{

	function __construct()
	{
	}

	function get_meters_to_nm($meters)
	{
		return round($meters * Configure::read('METERS_TO_NM'), 2);
	}

	function get_time_for_distance($distance_in_nm, $speed_in_kt)
	{
		$climbToCruise = 20;
		$descentToLand = 30;
		$removeOverlap = -40;

		$lineOfSight = round(($distance_in_nm / $speed_in_kt) * 60, 2);

		$totalEstimatedTime = $lineOfSight + $climbToCruise + $descentToLand + $removeOverlap;

		return $this->convertToHoursMins($totalEstimatedTime);
	}

	private function  convertToHoursMins($time, $format = '%02d:%02d') {
		if ($time < 1) {
			return;
		}
	$hours = floor($time / 60);
	$minutes = ($time % 60);
	return sprintf($format, $hours, $minutes);
	}

}
