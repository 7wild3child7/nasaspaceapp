<?php
class GoogleComponent extends Component
{
	private $googleUrl = "https://www.google.ro/webhp?sourceid=chrome-instant&ion=1&espv=2&ie=UTF-8#q=ro644";

	public function __construct()
	{

	}

	public function checkFlight($flightNumber)
	{
		$html = file_get_contents($this->googleUrl);
//		debug($html);

	}

}
