<?php
class WeatherComponent extends Component
{
	private $metarUrl = "http://www.aviationweather.gov/adds/metars/?station_ids=%s&std_trans=standard&chk_metars=on&hoursStr=most+recent+only&submitmet=Submit";
	function __construct()
	{
	}

	function getMetar($airportCode = 'LRCL')
	{
		$metarUrl = str_replace("%s", $airportCode, $this->metarUrl);
		$metarHtml = file_get_contents($metarUrl);

		$metarHtml = str_get_html($metarHtml);
		$departures_data = $metarHtml->find('td', 1);

		return trim($departures_data->plaintext);
	}

	function decode_metar($raw_metar = 'METAR LRCL 230900Z 09009KT 040V120 9999 FEW060 18/08 Q1008')
	{
		$decoder = new \MetarDecoder\MetarDecoder();
		$d = $decoder->parse($raw_metar);

		//surface wind
//		$sw = $d->getSurfaceWind(); //SurfaceWind object
//		//debug($sw);
//		debug($sw->getMeanDirection()->getValue()); //240
//		debug($sw->getMeanSpeed()->getValue()); //4'
//		debug($sw->getMeanSpeed()->getUnit());
//
//		$v = $d->getVisibility(); //Visibility object
//		debug($v->getVisibility()->getValue()); //2500
//		debug($v->getVisibility()->getUnit()); //'m'
//
//
//		$cld = $d->getClouds(); //CloudLayer array
//		debug($cld[0]->getAmount()); //'FEW'
//		debug($cld[0]->getBaseHeight()->getValue()); //1500
//		debug($cld[0]->getBaseHeight()->getUnit()); //'ft'
//
//		$rvr = $d->getRunwaysVisualRange(); //RunwayVisualRange array
//		debug($rvr);
//		//		debug($rvr[0]->getRunway()); //'32'
//		//		debug($rvr[0]->getVisualRange()->getValue()); //400
//
//		debug($d->getPressure()->getValue()); //1009
//		debug($d->getPressure()->getUnit()); //'hPa'
		return $d;
	}

	function getTaf($airportCode = 'LRCL')
	{
		$metarUrl = str_replace("%s", $airportCode, $this->metarUrl);
		$metarHtml = file_get_contents($metarUrl);

		$metarHtml = str_get_html($metarHtml);
		$departures_data = $metarHtml->find('td', 1);

		return trim($departures_data->plaintext);
	}

	function decode_taf($raw_taf = 'TAF LRCL 231100Z 2312/2321 09010KT CAVOK TEMPO 2312/2317 FEW050CB BECMG 2317/2319 VRB04KT')
	{
		$decoder = new \TafDecoder\TafDecoder();
		$d = $decoder->parse($raw_taf);

		//surface wind
//		$sw = $d->getSurfaceWind(); //SurfaceWind object
//		//debug($sw);
//		debug($sw->getMeanDirection()->getValue()); //240
//		debug($sw->getMeanSpeed()->getValue()); //4'
//		debug($sw->getMeanSpeed()->getUnit());
//
//		$v = $d->getVisibility(); //Visibility object
//		debug($v->getVisibility()->getValue()); //2500
//		debug($v->getVisibility()->getUnit()); //'m'
//
//
//		$cld = $d->getClouds(); //CloudLayer array
//		debug($cld[0]->getAmount()); //'FEW'
//		debug($cld[0]->getBaseHeight()->getValue()); //1500
//		debug($cld[0]->getBaseHeight()->getUnit()); //'ft'
//
//		$rvr = $d->getRunwaysVisualRange(); //RunwayVisualRange array
//		debug($rvr);
//		//		debug($rvr[0]->getRunway()); //'32'
//		//		debug($rvr[0]->getVisualRange()->getValue()); //400
//
//		debug($d->getPressure()->getValue()); //1009
//		debug($d->getPressure()->getUnit()); //'hPa'
		return $d;
	}

	function estimateTimeliness($weatherObject, $type, $ilsCat = 0)
	{

		if($ilsCat == '')
			$ilsCat = 0;
		$ilsConditions = Configure::read('ilsMinima');
		$ilsConditions = $ilsConditions[$ilsCat];

		$message = "";
		if($type = 'dep')
		{
			$temp = $weatherObject->getAirTemperature()->getValue();

			if($temp < 0 ) //17
				$message .= "<span class=\"delay\">Expect delays due to low temperatures</span><br>";

			$sw = $weatherObject->getSurfaceWind(); //SurfaceWind object
			if($sw)
			{
				if($sw->getMeanSpeed()->getValue() > 29)
					$message .="<span class=\"delay\">Expect delays due to strong wind </span><br>";
			}

			$v = $weatherObject->getVisibility(); //Visibility object
			if($v)
			{
				if($v->getVisibility()->getValue() < 400) //metri
					$message .= "<span class=\"delay\">Expect delays due to low visibility</span><br>";
			}
		}

		if($type == 'arr')
		{
			$sw = $weatherObject->getSurfaceWind();
			 //SurfaceWind object
			if($sw)
			{
				if($sw->getMeanSpeed()->getValue() > 33)
					$message .= "<span class=\"delay\">Expect delays due to strong wind </span><br>";
			}

			$v = $weatherObject->getVisibility(); //Visibility object
			if($v)
			{
				if($v->getVisibility()->getValue() < $ilsConditions['rvr']) //metri
					$message .= "<span class=\"delay\">Expect delays due to low visibility</span><br>";
			}

			$cld = $weatherObject->getClouds(); //CloudLayer array
			if($cld)
			{
				if (($cld[0]->getAmount() == 'BKN' || $cld[0]->getAmount() == 'OVC') && $cld[0]->getBaseHeight()->getValue() < $ilsConditions['dh']) // cer acoperit cu plafon la 200m
					$message .= "<span class=\"delay\">Expect delays due to low cloud base</span><br>";
			}
		}
		if($message == '')
			$message = "<span class=\"allGood\">No delays expected due to weather</span><br>";
		return $message;
	}
}
