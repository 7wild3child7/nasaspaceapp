<?php
class Fr24Component extends Component
{
	private $fr24FlitghtsFeed = "https://api.flightradar24.com/common/v1/flight/list.json?query=%s&fetchBy=flight&page=1&limit=25&token=tGtynJm6W1PrQObe98v_uZlJXuAHrAEj0uqBADppFK4&timestamp=";

	function __construct()
	{
	}

	public function getScheduledFlight($flightNo)
	{
		$fr24FullUrl = str_replace("%s", $flightNo,$this->fr24FlitghtsFeed);
		debug($fr24FullUrl);
		$flightList = file_get_contents($fr24FullUrl);

		$flightList = json_decode($flightList);

		$myFlight = $flightList->result->response->data[8];// urmatorul cel mai aproape zbor

		$scheduledTimeForTakeOff = date('d-m-Y H:i', $myFlight->time->scheduled->departure);
		$scheduledTimeForArrival = date('d-m-Y H:i', $myFlight->time->scheduled->arrival);

		if($myFlight->airport->origin->timezone->isDst)
			$scheduledTimeForTakeOff = date('d-m-Y H:i', $myFlight->time->scheduled->departure+3600);
		if($myFlight->airport->destination->timezone->isDst)
			$scheduledTimeForArrival = date('d-m-Y H:i', $myFlight->time->scheduled->arrival+3600);

		$results['departure_icao'] = $myFlight->airport->origin->code->icao;
		$results['arrival_icao'] = $myFlight->airport->destination->code->icao;

		$results['STD'] = $scheduledTimeForTakeOff;
		$results['STA'] = $scheduledTimeForArrival;

		return $results;

	}

}
