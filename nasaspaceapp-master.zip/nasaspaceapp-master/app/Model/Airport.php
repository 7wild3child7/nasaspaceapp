<?php
class Airport extends AppModel {
	public $name = 'Airport';
	public $useTable = "airports";

}
